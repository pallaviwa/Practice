        package utility;

        import io.appium.java_client.AppiumDriver;
        import io.appium.java_client.MobileElement;
        import io.appium.java_client.TouchAction;
        import io.appium.java_client.android.AndroidDriver;
        import io.appium.java_client.android.AndroidElement;
        import io.appium.java_client.touch.TapOptions;
        import io.appium.java_client.touch.offset.ElementOption;
        import io.appium.java_client.touch.offset.PointOption;
        import org.openqa.selenium.Dimension;
        import org.openqa.selenium.interactions.touch.TouchActions;

        import java.net.MalformedURLException;
        import java.time.Duration;

        import static io.appium.java_client.touch.WaitOptions.waitOptions;

        public class TouchActionsAndroid extends BaseTest {

            private AndroidDriver driver;
            TouchAction action;

            public TouchActionsAndroid(AndroidDriver driver) throws MalformedURLException {
                this.driver = driver;
                action = new TouchAction(driver);
            }

            public void tapElement(AndroidElement androidElement) {

                action.tap(TapOptions.tapOptions().withElement(ElementOption.element(androidElement))).waitAction(waitOptions(Duration.ofMillis(250))).perform();

            }

            public void swipeByElement(AndroidElement startElement, AndroidElement endElement) {
                Dimension size = this.driver.manage().window().getSize();
                System.out.println("Size is " + size);
                //int startX = (Int)startElement.getLocation().getX() + (startElement.getSize().getWidth()*0.8);
                int startX = (int) ((driver.manage().window().getSize().getWidth()) * 0.80);
                int endX = (int) ((driver.manage().window().getSize().getWidth()) * 0.20);


                int startY = startElement.getLocation().getY();

                //+ (startElement.getSize().getHeight() / 7)
                //int endX = endElement.getLocation().getX() + (startElement.getSize().getWidth()*0.20);
                //int endY = endElement.getLocation().getX() + (endElement.getSize().getHeight() / 7);

                action.press(PointOption.point(startX, startY)).waitAction(waitOptions(Duration.ofMillis(2000))).moveTo(PointOption.point(endX, startY)).release().perform();
            }

            public void swipeByUiAutomator(AndroidElement androidElement){

                System.out.println("Horizontal swipe by uiAutomator method scrollIntoView");
                AndroidElement elementToClick = (AndroidElement) driver
                        .findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
                                + ".resourceId(\"com.android.vending:id/title\")).scrollIntoView("
                                + "new UiSelector().text(\"Editors' Choice\"));");
                elementToClick.click();

            }
        }





            // action.press(PointOption.point(startX, startY)).waitAction(waitOptions(Duration.ofMillis(1000))).moveTo(PointOption.point(endX, endY)).waitAction(waitOptions(Duration.ofMillis(500))).release();*/
    //Working Code:
               /* AndroidElement elementToClick = (AndroidElement) driver
                        .findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
                                + ".resourceId(\"com.android.vending:id/title\")).scrollIntoView("
                                + "new UiSelector().text(\"Editors' Choice\"));");
                elementToClick.click();



            }

            /*public void horozantalSWipeByElementsTouchAction(AndroidElement startElement,AndroidElement endElement){


                    action.press(startElement).waitAction(Duration.ofSeconds(2)).moveTo(endElement).release().perform();
                }*/








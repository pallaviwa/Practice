package utility;

public class BaseScreen {

}

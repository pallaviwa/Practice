    package utility;

            import io.appium.java_client.AppiumDriver;
            import io.appium.java_client.android.AndroidDriver;
            import io.appium.java_client.remote.AndroidMobileCapabilityType;
            import io.appium.java_client.remote.MobileCapabilityType;
            import org.openqa.selenium.remote.DesiredCapabilities;
            import org.testng.annotations.BeforeClass;
            import org.testng.annotations.BeforeSuite;
            import org.testng.annotations.BeforeTest;

            import java.io.FileInputStream;
            import java.io.InputStream;
            import java.net.MalformedURLException;
            import java.net.URL;
            import java.util.Properties;
            import java.util.concurrent.TimeUnit;

    public class BaseTest {
        private  AndroidDriver driver;
        private  String path = "D:\\Intelli_Java\\TouchActions_Android\\src\\main\\resources\\testconfig.properties";

        Properties prop = new Properties();

        private   void propertyLoad() {
            InputStream input = null;
            try {
                input = new FileInputStream(path);

                prop.load(input);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        @BeforeSuite
        public  AndroidDriver getAndroidDriver() throws MalformedURLException {
            AndroidDriver aDriver;
            propertyLoad();
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability(AndroidMobileCapabilityType.PLATFORM_NAME, prop.getProperty("Android"));
            capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.getProperty("APP_ACTIVITY"));
            capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.getProperty("APP_PACKAGE"));
            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.getProperty(("DEVICE_NAME")));
            capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, prop.getProperty("PLATFORM_VERSION"));
            aDriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            return aDriver;

        }

        private void capabilities_iOS() throws MalformedURLException {

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("platFormName", "iOS");
            capabilities.setCapability("deviceName", "iPhone7");
            capabilities.setCapability("platformVersion", "11.0");
        }

        public  AndroidDriver getDriver() throws MalformedURLException {
            String oS = "Android";
            switch (oS) {
                case "Android":
                    driver = getAndroidDriver();
                    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                    return driver;
                case "IOS":
                    return null;
            }
            return driver;

        }
    }
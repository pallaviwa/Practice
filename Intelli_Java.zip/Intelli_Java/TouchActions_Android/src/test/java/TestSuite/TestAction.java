package TestSuite;

import io.appium.java_client.android.AndroidDriver;
import org.testng.annotations.Test;
import pages.AppPage;
import utility.BaseTest;

import java.net.MalformedURLException;


    public class TestAction extends BaseTest {
         public AndroidDriver driver;

        @Test
        public void test() throws MalformedURLException, InterruptedException {
            AppPage app=new AppPage(getDriver());
            //String tab="Early access";
            System.out.println("App ,launched");


                if (app.tabIsSelected(app.getTopCharts()));

                if (app.isElementGetDisplayed(app.getBtnTopFree())) {
                    System.out.println("Top charts displayed");
                }
/*app.swipetab(app.getEditorsChoice(),app.getCategories());
                if(app.isElementGetDisplayed(app.getEarlyAccess())){
                    System.out.println("Swipe worked");

            }*/

              //Horizantal Swipe screen
                 app.swipeByScrollIntoView(app.getEditorsChoice1());
                 Thread.sleep(4000);

                    if (app.isElementGetDisplayed(app.getEarlyAccess())) {
                        app.tabIsSelected(app.getEarlyAccess());

                        System.out.println("Horizontal Swipe worked");
                    }

                }
        }


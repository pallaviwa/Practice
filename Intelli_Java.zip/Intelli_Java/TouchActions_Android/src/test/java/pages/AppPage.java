        package pages;

                import io.appium.java_client.FindsByAndroidUIAutomator;
                import io.appium.java_client.android.AndroidDriver;
                import io.appium.java_client.android.AndroidElement;
                import io.appium.java_client.pagefactory.AndroidFindBy;
                import io.appium.java_client.pagefactory.AppiumFieldDecorator;

                import org.openqa.selenium.support.PageFactory;
                import utility.BaseTest;
                import utility.TouchActionsAndroid;

                import java.awt.*;
                import java.net.MalformedURLException;

            public class AppPage extends BaseTest {
                public AndroidDriver driver;
                TouchActionsAndroid touchActionsAndroid;

                public AppPage(AndroidDriver driver) throws MalformedURLException {
                    this.driver = driver;
                    touchActionsAndroid = new TouchActionsAndroid(driver);
                    PageFactory.initElements(new AppiumFieldDecorator(driver), this);
                }

                @AndroidFindBy(xpath = "//android.widget.TextView[@text='Top charts']")
                AndroidElement TopCharts;

                @AndroidFindBy(xpath = "//android.widget.TextView[@text='Categories']")

                AndroidElement Categories;
                @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Editors' Choice\"]")
                AndroidElement EditorsChoice;
                public AndroidElement getEditorsChoice() {
                    return EditorsChoice;
                }

                public AndroidElement getFamily() {
                    return Family;
                }

                @AndroidFindBy(xpath = "//android.widget.TextView[@text='Family']" )
                AndroidElement Family;
                @AndroidFindBy(xpath = "//android.widget.TextView[@text='Early access']")
                AndroidElement EarlyAccess;
                public AndroidElement getEarlyAccess() {
                    return EarlyAccess;
                }

                @AndroidFindBy(xpath = "//android.widget.Button[@text='Top Free Apps']")
                AndroidElement BtnTopFree;





                public AndroidElement getCategories() {
                    return Categories;
                }

                public AndroidElement getTopCharts() {
                    return TopCharts;
                }


                public AndroidElement getBtnTopFree() {
                    return BtnTopFree;
                }

                public boolean tabIsSelected(AndroidElement androidElement) {

                    touchActionsAndroid.tapElement(androidElement);

                    return androidElement.isSelected();

                }

                public boolean isElementGetDisplayed(AndroidElement androidElement) {
                    return androidElement.isDisplayed();
                }


    //Scrolling with UI automator
                @AndroidFindBy(uiAutomator = "//new UiScrollable(new UiSelector()\"\n" +
                        "                        + \".resourceId(\\\"com.android.vending:id/title\\\")).scrollIntoView(\"\n" +
                        "                        + \"new UiSelector().text(\\\"Editors' Choice\\\"))")
                AndroidElement EditorsChoice1;
                public AndroidElement getEditorsChoice1() {

                        return EditorsChoice1;
                }


                public AndroidElement getEarlyAccessui() {
                    return EarlyAccessui;
                }

                @AndroidFindBy(uiAutomator = "//new UiScrollable(new UiSelector()\"\n" +
                 "                        + \".resourceId(\\\"com.android.vending:id/title\\\")).scrollIntoView(\"\n" +
                 "                        + \"new UiSelector().text(\\\"Early' Access\\\"))" )
           AndroidElement  EarlyAccessui;



    public void swipeByScrollIntoView(AndroidElement androidElement){
                    touchActionsAndroid.swipeByUiAutomator(androidElement);

    }
                public void swipetab(AndroidElement androidElement, AndroidElement androidelement1) {

                    touchActionsAndroid.swipeByElement(androidElement,androidelement1);
                }



            }




















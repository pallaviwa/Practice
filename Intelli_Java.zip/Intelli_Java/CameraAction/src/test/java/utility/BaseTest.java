package utility;


import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Driver;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class BaseTest {

private AndroidDriver driver;

private String path="D:\\Intelli_Java\\CameraAction\\src\\main\\resources\\testconfig.properties";

Properties property=new Properties();


private void properyLoad ()  {
        InputStream input=null;

   try {
       input = new FileInputStream(path);
property.load(input);
   }catch (Exception e){
       e.printStackTrace();
   }
}

private AndroidDriver getAndroidDriver() throws MalformedURLException {
    AndroidDriver aDriver;
    DesiredCapabilities capabilities=new DesiredCapabilities();

    properyLoad();

    capabilities.setCapability(AndroidMobileCapabilityType.PLATFORM_NAME, property.getProperty("PLATFORM_NAME"));
    capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE,property.getProperty("APP_PACKAGE"));
    capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY,property.getProperty("APP_ACTIVITY"));
    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,property.getProperty("DEVICE_NAME"));
    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,property.getProperty("PLATFORM_VERSION"));
    aDriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);

    return aDriver;

}
private IOSDriver getIosDriver() throws MalformedURLException {
    IOSDriver iosDriver;

    DesiredCapabilities capabilities=new DesiredCapabilities();
    capabilities.setCapability(IOSMobileCapabilityType.APP_NAME,property.getProperty("APP_ACTIVITY"));
    iosDriver=new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
    return iosDriver;
}

public AndroidDriver getDriver() throws MalformedURLException {
    String platform = "Android";

    switch (platform) {

        case "Android":
            driver = getAndroidDriver();
           driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            return driver;

        case "IOS":

            return null;
    }
    return driver;
}


}




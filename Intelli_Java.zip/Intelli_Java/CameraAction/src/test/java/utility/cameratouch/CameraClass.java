package utility.cameratouch;

import io.appium.java_client.android.AndroidDriver;
import org.aspectj.weaver.ast.And;
import utility.BaseTest;

public class CameraClass extends BaseTest {

    AndroidDriver driver;

    public CameraClass(AndroidDriver driver){

        this.driver=driver;

    }

public void cameraTouchMethod(){

    AndroidDriver driver;


}

}




package testsuite;

import io.appium.java_client.android.AndroidDriver;
import utility.BaseTest;

import java.net.MalformedURLException;

public class TestRun extends BaseTest {
AndroidDriver driver;
public TestRun (AndroidDriver driver){

this.driver=driver;
}

public void test() throws MalformedURLException {


    }


}

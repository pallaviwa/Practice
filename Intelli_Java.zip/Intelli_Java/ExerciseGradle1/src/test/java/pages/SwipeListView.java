package pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.support.PageFactory;
import utility.BaseTest;

public class SwipeListView extends BaseTest {

private AndroidDriver driver;

    public SwipeListView(AndroidDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Default Print Service']")
    MobileElement defaultPrintService;


    public MobileElement getDefaultPrintService() {
        return defaultPrintService;
    }

    public void setDefaultPrintService(MobileElement defaultPrintService) {
        this.defaultPrintService = defaultPrintService;
    }

    public MobileElement getAlert() {
        return alert;
    }

    public void setAlert(MobileElement alert) {
        this.alert = alert;
    }
public boolean displays(MobileElement element){
     return element.isDisplayed();
}
    public MobileElement getButton() {
        return button;
    }

    public void setButton(MobileElement button) {
        this.button = button;
    }

    @AndroidFindBy(xpath = "//android.widget.Button[@text='Ok']")
    MobileElement button;


    @AndroidFindBy(xpath = "//android.widget.TextView[@text='SwipeListView Demo']" )
    MobileElement alert;

    public MobileElement getAlert1() {
        return alert1;
    }

    public void setAlert1(MobileElement alert1) {
        this.alert1 = alert1;
    }

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='About']" )
    MobileElement alert1;
    public void Mclick(MobileElement element){
        element.click();

    }

    public void sendValues(MobileElement element, String values){
        element.sendKeys(values);
    }
}

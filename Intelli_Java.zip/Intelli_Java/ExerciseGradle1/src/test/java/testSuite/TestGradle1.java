package testSuite;

import io.appium.java_client.android.AndroidDriver;
import org.testng.annotations.Test;
import pages.SwipeListView;
import utility.BaseTest;

public class TestGradle1 extends BaseTest {
    private AndroidDriver driver;

    public TestGradle1(AndroidDriver driver) {

        this.driver = driver;
    }


    @Test
    public void test()throws Exception{

        SwipeListView swipeListView = new SwipeListView(driver);
        System.out.println("Android app launched");

            swipeListView.Mclick(swipeListView.getAlert());
            swipeListView.Mclick(swipeListView.getButton());
            swipeListView.Mclick(swipeListView.getAlert1());
            swipeListView.Mclick(swipeListView.getButton());


        }
        //swipeListView.Mclick(swipeListView.getButton());
        //swipeListView.Mclick(swipeListView.getButton());
        //String text= swipeListView.getDefaultPrintService().getText();

    }







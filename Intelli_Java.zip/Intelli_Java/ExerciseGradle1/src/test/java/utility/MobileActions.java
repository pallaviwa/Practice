package utility;

import io.appium.java_client.android.AndroidDriver;

/*public class MobileActions {

    public AndroidDriver driver;

    public MobileActions(AndroidDriver driver){
        this.driver=driver;
//
//           }*/








/*package utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyRead {
private String path= "D:\\Intelli_Java\\ExerciseGradle1\\src\\main\\resources\\TestConfig.properties";
    public PropertyRead() {


        Properties property = new Properties();
        InputStream input = null;
        try {
            input = new FileInputStream(path);
            property.load(input);


        }catch(Exception e ){
            e.printStackTrace();
        }
    }
    }*/




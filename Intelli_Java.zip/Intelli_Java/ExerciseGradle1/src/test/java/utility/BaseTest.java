package utility;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import pages.SwipeListView;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

public class BaseTest {

    private AppiumDriver driver;

    //PropertyRead prop=new PropertyRead();
    private String path = "D:\\Intelli_Java\\ExerciseGradle1\\src\\main\\resources\\TestConfig.properties";

    private Properties property = new Properties();


    private void propertyread() {


        //Properties property = new Properties();
        InputStream input = null;
        try {
            input = new FileInputStream(path);
            property.load(input);


        } catch (
                Exception e) {
            e.printStackTrace();
        }


    }

    private void capabilities_iOS() throws MalformedURLException {

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platFormName", "iOS");
        capabilities.setCapability("deviceName", "iPhone7");
        capabilities.setCapability("platformVersion", "11.0");
    }

    protected void platformSelection() throws MalformedURLException {
        String oS = "Android";
        switch (oS) {
            case "Android":

                driver = getAndroidDriver();
                break;
            case "iOS":
                break;
        }
    }


    private AndroidDriver getAndroidDriver() throws MalformedURLException {
        AndroidDriver aDriver;
        propertyread();
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(AndroidMobileCapabilityType.PLATFORM_NAME, property.getProperty("PLATFORM_NAME"));
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, property.getProperty("APP_PACKAGE"));
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, property.getProperty("APP_ACTIVITY"));
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, property.getProperty("DEVICE_NAME"));
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, property.getProperty("PLATFORM_VERSION"));
        capabilities.setCapability("autoDismissAlerts", true);

        /*capabilities.setCapability(AndroidMobileCapabilityType.PLATFORM_NAME,"Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,"emulator-5554");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "9.0");
        capabilities.setCapability("automationName","uiautomator2");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE,"com.example.android.contactmanager");
        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.example.android.contactmanager.ContactManager");*/

        aDriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

        return aDriver;
    }

   /* public void dismissAlert(AndroidDriver driver) {
        swipeListView = new SwipeListView(driver)
        if (swipeListView.getAlert().isDisplayed()) {
            swipeListView.Mclick(swipeListView.getButton());
        }
    }*/
}




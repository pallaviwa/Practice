package com.pallavi;

import org.testng.annotations.Test;

public class SeleniumDemo {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}

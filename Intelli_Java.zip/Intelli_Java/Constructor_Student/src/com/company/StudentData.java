package com.company;

 class StudentData {
     private  String stuName;
    private int stuId;
    private int stuAge;

     StudentData(){
         stuName="Stu1";
         stuId=101;
         stuAge=19;
     }

     StudentData(String name,int age, int id){
         this.stuName=name;
         this.stuAge=age;
         this.stuId=id;
     }

     //Getter Settre
     public String getStuName() {
         return stuName;
     }

     public int getStuId() {
         return stuId;
     }

     public int getStuAge() {
         return stuAge;
     }

    public static void main(String[] args) {
        StudentData stu=new StudentData();
        System.out.println("Student ID : " +stu.getStuId());
        System.out.println("Student Age : " +stu.getStuAge());
        System.out.println("Student Name: " +stu.getStuName());

        StudentData stu1=new StudentData("Pallavi",20,100);
        System.out.println("Student ID from P constructor: " +stu1.getStuId());
        System.out.println("Student Age from P constructor: " +stu1.getStuAge());
        System.out.println("Student Name from P constructor: "+stu1.getStuName());

     }
}

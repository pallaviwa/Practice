package com.pal;

public class OverloadingExample2{

    private int rolNumber;
    OverloadingExample2()
    {
        rolNumber =100;
    }
    OverloadingExample2(int rnum)
    {
       this();
        /*this() is used for calling the default
         * constructor from parameterized constructor.
         * It should always be the first statement
         * inside constructor body.
         */
        rolNumber = rolNumber+ rnum;
        System.out.println("Roll : " + rolNumber);
    }
    public int getRollNum() {
        return rolNumber;
    }
    public void setRollNum(int rollNum) {
        this.rolNumber = rollNum;
    }
    public static void main(String args[])
    {
        OverloadingExample2 obj = new OverloadingExample2(12);
        //obj.setRollNum(200);

        System.out.println(obj.getRollNum());

    }


}
